<p align="center"> <img src="https://imgur.com/5OSxg3h.png" alt="Javascript: validando formulários"> </p>

<hr>

<p align="center"> <img src="https://github.com/MonicaHillman/aluraplay-requisicoes/blob/main/img/logo.png" alt="Logo da Alura"> </p>
<p align="center">Cinetag: sua plataforma de streaming de filmes relacionados a tecnologia.</p>

## Assuntos abordados durante o curso
* React
* React-router-dom
* Module CSS
* ContextAPI
* Hooks

## Outras tecnologias utilizadas no projeto
* HTML
* CSS
* JavaScript
