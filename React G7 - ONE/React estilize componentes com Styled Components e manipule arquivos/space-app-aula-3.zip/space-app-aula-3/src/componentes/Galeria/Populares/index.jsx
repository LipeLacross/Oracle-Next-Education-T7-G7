import Titulo from "../../Titulo"

const Populares = () => {
    return <div style={{ minWidth: 212 }}>
        <Titulo $alinhamento="center">Populares</Titulo>
    </div>
}

export default Populares