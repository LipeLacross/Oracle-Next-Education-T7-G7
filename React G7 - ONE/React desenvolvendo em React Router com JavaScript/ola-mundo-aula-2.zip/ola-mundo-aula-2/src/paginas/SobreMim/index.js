export default function SobreMim() {
    return (
        <h1>Sobre mim...</h1>
    )
}