import Banner from "componentes/Banner";

export default function Inicio() {
    return (
        <main>
            <Banner />

            <h1>Olá mundo!</h1>
        </main>
    )
}