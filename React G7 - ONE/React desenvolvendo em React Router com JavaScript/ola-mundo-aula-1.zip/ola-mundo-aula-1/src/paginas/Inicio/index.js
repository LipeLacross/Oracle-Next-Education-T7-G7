export default function Inicio() {
    return (
        <h1>Olá mundo!</h1>
    )
}